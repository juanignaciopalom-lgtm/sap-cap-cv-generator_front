sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/VBox",
    "sap/m/HBox",
    "sap/m/Text",
    "sap/m/Title",
    "sap/ui/core/Icon"
], function (
    Controller,
    JSONModel,
    ODataModel,
    Filter,
    FilterOperator,
    MessageToast,
    Dialog,
    Button,
    VBox,
    HBox,
    Text,
    Title,
    Icon
) {
    "use strict";

    return Controller.extend("cv.viewer.cvviewer.controller.View1", {

        onInit: function () {
            var oView = this.getView();
            var that = this;

            var oLocalModel = new JSONModel({
                profile: {},
                skills: [],
                experiences: [],
                projects: [],
                education: [],
                certifications: [],
                languages: []
            });
            oView.setModel(oLocalModel, "cv");

            var oODataModel = new ODataModel({
                serviceUrl: "/api/public/",
                synchronizationMode: "None",
                operationMode: "Server",
                autoExpandSelect: true
            });

            oODataModel.bindList("/Profile").requestContexts(0, 1)
                .then(function (aProfileContexts) {
                    if (!aProfileContexts.length) {
                        return;
                    }

                    var oProfile = aProfileContexts[0].getObject();
                    var sProfileId = oProfile.ID;
                    var oModel = that.getView().getModel("cv");

                    oModel.setProperty("/profile", oProfile);

                    return Promise.all([
                        oODataModel.bindList("/Skills", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100),

                        oODataModel.bindList("/Experiences", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100),

                        oODataModel.bindList("/Projects", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100),

                        oODataModel.bindList("/Education", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100),

                        oODataModel.bindList("/Certifications", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100),

                        oODataModel.bindList("/Languages", undefined, undefined, [
                            new Filter("profile_ID", FilterOperator.EQ, sProfileId)
                        ]).requestContexts(0, 100)
                    ]).then(function (aResults) {
                        var aSkills = aResults[0].map(function (c) { return c.getObject(); });
                        var aExperiences = aResults[1].map(function (c) { return c.getObject(); });
                        var aProjects = aResults[2].map(function (c) { return c.getObject(); });
                        var aEducation = aResults[3].map(function (c) { return c.getObject(); });
                        var aCerts = aResults[4].map(function (c) { return c.getObject(); });
                        var aLanguages = aResults[5].map(function (c) { return c.getObject(); });

                        aSkills = that._sortSkills(aSkills);
                        aExperiences = that._sortExperiences(aExperiences);

                        aCerts.sort(function (a, b) {
                            return (b.issueYear || 0) - (a.issueYear || 0);
                        });

                        oModel.setProperty("/skills", aSkills);
                        oModel.setProperty("/experiences", aExperiences);
                        oModel.setProperty("/projects", aProjects);
                        oModel.setProperty("/education", aEducation);
                        oModel.setProperty("/certifications", aCerts);
                        oModel.setProperty("/languages", aLanguages);

                        that._snapInitialized = false;
                        setTimeout(function () { that._initSnapScroll(); }, 600);
                    });
                })
                .catch(function (oError) {
                    console.error("Error:", oError);
                });

            this.getView().addEventDelegate({
                onAfterRendering: function () {
                    setTimeout(function () { that._initSnapScroll(); }, 300);
                }
            });
        },

        _getSkillCategoryOrder: function () {
            return [
                "Backend",
                "Frontend",
                "SAP",
                "Database",
                "Base de Datos",
                "Bases de Datos",
                "Cloud",
                "DevOps",
                "Soft Skill",
                "Other",
                "Otros",
                "Herramientas",
                "Tools"
            ];
        },

        _sortSkills: function (aSkills) {
            var aCategoryOrder = this._getSkillCategoryOrder();

            return aSkills.slice().sort(function (a, b) {
                var sCatA = (a.category || "Other").trim();
                var sCatB = (b.category || "Other").trim();

                var iCatA = aCategoryOrder.indexOf(sCatA);
                var iCatB = aCategoryOrder.indexOf(sCatB);

                iCatA = iCatA === -1 ? 999 : iCatA;
                iCatB = iCatB === -1 ? 999 : iCatB;

                if (iCatA !== iCatB) {
                    return iCatA - iCatB;
                }

                return (a.name || "").localeCompare((b.name || ""), "es", { sensitivity: "base" });
            });
        },

        _sortExperiences: function (aExperiences) {
            return aExperiences.slice().sort(function (a, b) {
                var iA = this._toTime(a.startDate);
                var iB = this._toTime(b.startDate);

                if (iA !== iB) {
                    return iA - iB;
                }

                var iEndA = this._toTime(a.endDate);
                var iEndB = this._toTime(b.endDate);

                return iEndA - iEndB;
            }.bind(this));
        },

        _toTime: function (vDate) {
            if (!vDate) {
                return 0;
            }

            var iTime = new Date(vDate).getTime();
            return isNaN(iTime) ? 0 : iTime;
        },

        _initSnapScroll: function () {
            if (this._snapInitialized) return;

            var oPageDom = this.byId("page").getDomRef();
            if (!oPageDom) return;

            var oScroller = oPageDom.querySelector(".sapMPageScroll");
            if (!oScroller) return;

            var aSections = Array.from(
                oScroller.querySelectorAll(".cvSnapSection")
            ).filter(function (el) {
                return el.offsetHeight > 0;
            });

            if (!aSections.length) return;

            this._snapInitialized = true;
            var bScrolling = false;

            var fnGetCurrent = function () {
                var iScrollTop = oScroller.scrollTop;
                var iBest = 0;
                var iMin = Infinity;
                aSections.forEach(function (oSec, i) {
                    var iDist = Math.abs(oSec.offsetTop - iScrollTop);
                    if (iDist < iMin) {
                        iMin = iDist;
                        iBest = i;
                    }
                });
                return iBest;
            };

            var fnScrollTo = function (iIndex) {
                if (iIndex < 0 || iIndex >= aSections.length) return;
                bScrolling = true;
                aSections[iIndex].scrollIntoView({ behavior: "smooth", block: "start" });
                setTimeout(function () { bScrolling = false; }, 900);
            };

            oScroller.addEventListener("wheel", function (oEvent) {
                oEvent.preventDefault();
                if (bScrolling) return;
                fnScrollTo(oEvent.deltaY > 0 ? fnGetCurrent() + 1 : fnGetCurrent() - 1);
            }, { passive: false });

            var iTouchStartY = 0;
            oScroller.addEventListener("touchstart", function (oEvent) {
                iTouchStartY = oEvent.touches[0].clientY;
            }, { passive: true });

            oScroller.addEventListener("touchend", function (oEvent) {
                if (bScrolling) return;
                var iDelta = iTouchStartY - oEvent.changedTouches[0].clientY;
                if (Math.abs(iDelta) < 40) return;
                fnScrollTo(iDelta > 0 ? fnGetCurrent() + 1 : fnGetCurrent() - 1);
            }, { passive: true });

            document.addEventListener("keydown", function (oEvent) {
                if (bScrolling) return;
                if (oEvent.key === "ArrowDown" || oEvent.key === "PageDown") {
                    oEvent.preventDefault();
                    fnScrollTo(fnGetCurrent() + 1);
                } else if (oEvent.key === "ArrowUp" || oEvent.key === "PageUp") {
                    oEvent.preventDefault();
                    fnScrollTo(fnGetCurrent() - 1);
                }
            });
        },

        onOpenProject: function (oEvent) {
            var oCtx = oEvent.getSource().getBindingContext("cv");
            var sUrl = oCtx.getProperty("projectUrl");
            if (sUrl) { window.open(sUrl, "_blank"); }
        },

        onLinkedIn: function () {
            var sUrl = this.getView().getModel("cv").getProperty("/profile/linkedinUrl");
            if (sUrl) { window.open(sUrl, "_blank"); }
            else { MessageToast.show("LinkedIn no configurado"); }
        },

        onGitHub: function () {
            var sUrl = this.getView().getModel("cv").getProperty("/profile/githubUrl");
            if (sUrl) { window.open(sUrl, "_blank"); }
            else { MessageToast.show("GitHub no configurado"); }
        },

        onAboutApp: function () {
            if (this._oAboutDialog) {
                this._oAboutDialog.open();
                return;
            }

            var oIntroTitle = new Title({
                text: "CV Viewer sobre SAP BTP",
                level: "H4"
            }).addStyleClass("cvAboutMainTitle");

            var oIntroText = new Text({
                text: "Aplicación desarrollada como portfolio técnico para mostrar una solución full-stack dentro del ecosistema SAP. Permite administrar y visualizar un CV profesional con información dinámica persistida en base de datos."
            }).addStyleClass("cvAboutIntroText");

            var oContent = new VBox({
                items: [
                    oIntroTitle,
                    oIntroText,
                    this._createAboutRow(
                        "sap-icon://target-group",
                        "Propósito",
                        "Fue pensada para demostrar una aplicación real construida con tecnologías SAP modernas, con foco en experiencia visual, persistencia, arquitectura limpia y despliegue en la nube."
                    ),
                    this._createAboutRow(
                        "sap-icon://process",
                        "Tecnologías",
                        "Frontend en SAP UI5, backend en SAP CAP con Node.js, autenticación con XSUAA, despliegue en SAP BTP Cloud Foundry y persistencia en PostgreSQL."
                    ),
                    this._createAboutRow(
                        "sap-icon://split",
                        "Arquitectura",
                        "La solución se compone de un approuter, un frontend UI5, un backend CAP y una base PostgreSQL. El frontend consume servicios públicos del backend para renderizar toda la información del perfil."
                    ),
                    this._createAboutRow(
                        "sap-icon://developer-settings",
                        "Construcción del proyecto",
                        "El proyecto incluye un wizard de administración para cargar y actualizar la información del CV, y una vista pública orientada a portfolio para mostrar skills, experiencia, proyectos, educación, certificaciones e idiomas."
                    )
                ]
            }).addStyleClass("cvAboutDialogContent sapUiContentPadding");

            this._oAboutDialog = new Dialog({
                title: "Acerca de la app",
                contentWidth: "700px",
                horizontalScrolling: false,
                verticalScrolling: true,
                content: [oContent],
                beginButton: new Button({
                    text: "Cerrar",
                    press: function () {
                        this._oAboutDialog.close();
                    }.bind(this)
                })
            });

            this.getView().addDependent(this._oAboutDialog);
            this._oAboutDialog.open();
        },

        _createAboutRow: function (sIcon, sTitle, sText) {
            var oIcon = new Icon({
                src: sIcon
            }).addStyleClass("cvAboutRowIcon");

            var oTitle = new Title({
                text: sTitle,
                level: "H5"
            }).addStyleClass("cvAboutRowTitle");

            var oText = new Text({
                text: sText
            }).addStyleClass("cvAboutRowText");

            var oTextBox = new VBox({
                items: [oTitle, oText]
            }).addStyleClass("cvAboutRowTextBox");

            return new HBox({
                alignItems: "Start",
                items: [oIcon, oTextBox]
            }).addStyleClass("cvAboutRow");
        }
    });
});