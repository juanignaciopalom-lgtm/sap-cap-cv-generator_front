sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("cv.viewer.cvviewer.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map