sap.ui.define(["cv/viewer/cvviewer/test/unit/controller/View1.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map