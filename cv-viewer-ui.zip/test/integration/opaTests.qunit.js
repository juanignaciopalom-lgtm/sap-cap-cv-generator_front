QUnit.config.autostart=false;sap.ui.require(["cv/viewer/cvviewer/test/integration/AllJourneys"],function(){QUnit.start()});
//# sourceMappingURL=opaTests.qunit.js.map